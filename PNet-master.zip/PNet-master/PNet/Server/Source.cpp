//Server Code
#include <PNet\IncludeMe.h>

int main()
{
	int value = PNet::ReturnFive();
	return 0;
}