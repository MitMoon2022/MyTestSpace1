#include "IncludeMe.h"

namespace PNet
{
	int ReturnFive()
	{
		return 5;
	}
}