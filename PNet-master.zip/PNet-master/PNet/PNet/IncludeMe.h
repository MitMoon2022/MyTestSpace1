#pragma once

namespace PNet
{
	int ReturnFive();
}